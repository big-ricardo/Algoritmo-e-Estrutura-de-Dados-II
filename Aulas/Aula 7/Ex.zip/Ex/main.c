#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#include "hash.h"

/*
  Luis Ricardo Albano Santos - 2021031844
  gcc -pedantic-errors -Wall main.c -o main.exe && ./main.exe
*/

int main(void) {

  hash* h = criaHash(10);

  insere(h, "teste");
  insere(h, "teste2");
  insere(h, "teste3");
  insere(h, "teste4");
  insere(h, "teste5");
  insere(h, "teste6");

  // percorre(h, 0);

  printf("%d\n", getTamanhoLista(h, 2));

  // printf("%d\n", encontraElemento(h, "teste"));

  // printf("%d\n", encontraElemento(h, "teste2"));

  // printf("%d\n", encontraElemento(h, "teste7"));


  return 0;

}
